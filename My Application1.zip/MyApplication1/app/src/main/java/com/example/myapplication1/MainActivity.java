package com.example.myapplication1;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.view.View;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.MenuItem;
import android.view.Menu;


public class MainActivity extends AppCompatActivity {

    public void fade (View view){


        /*
        ImageView purdue = (ImageView) findViewById(R.id.imageView2);
        purdue.animate().translationYBy(500).setDuration(500);
        */

    }

    public void editText (View view){
        EditText editText = (EditText) findViewById(R.id.editText);
        Log.i("Info", editText.getText().toString());
        Toast.makeText(MainActivity.this,"Welcome, " + editText.getText().toString(), Toast.LENGTH_LONG).show();
        ImageView purdue = (ImageView) findViewById(R.id.imageView2);
        purdue.animate().rotation(1080f).setDuration(500);
        purdue.animate().scaleY(20f).scaleX(20f).setDuration(250);
        //purdue.animate().scaleY(0.2f).scaleX(.2f).setDuration(250);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Handler handler = new Handler();
        Runnable run = new Runnable() {
            @Override
            public void run() {
                //inser code to be runn second kinda liike a loop
                Log.i("Runnabble has run!","A second must have been gone");
                handler.postDelayed(this,100);

            }
        };
        handler.post(run);




        /*
        ImageView purdue = (ImageView) findViewById(R.id.imageView2);
        purdue.setTranslationY(-2000);
        */
    }

}
